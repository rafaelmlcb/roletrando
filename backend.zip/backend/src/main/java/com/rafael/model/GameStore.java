package com.rafael.model;

import java.util.HashMap;
import java.util.Map;

public class GameStore {
    public static final Map<String, String> phrases = new HashMap<>();
    public static final Map<String, GameSession> sessions = new HashMap<>();
}
